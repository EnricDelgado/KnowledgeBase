[ESP] versión 0.0.4

*IMPORTANTE: Si has obtenido una copia legal de este libro, todas sus actualizaciones futuras serán entregadas de manera gratuita, hasta que sea completado.
El libro contendrá más de 200 páginas, y contempla los capítulos:

- Functions Polinomiales (final con revisiones).
- Funciones Trigonométricas (final con revisiones).
- Dibujando con funciones Polinomiales (final con revisiones).
- Análisis de figuras 2D SDF (final con revisiones).
- Análisis de figuras 3D SDF (en proceso).

El libro ha sido escrito en español neutro.

---------------------------------------------------------------------------------------------------------------------------------

[ENG] version 0.0.4

*IMPORTANT: If you have obtained a legal copy of this book, all future updates will be delivered for free until it is completed. 
The book will contain more than 200 pages, and will include the chapters:

- Polynomial Functions (final with revisions).
- Trigonometric Functions (final with revisions).
- Drawing with Polynomial Functions (final with revisions).
- Analysis of 2D SDF Figures (final with revisions).
- Analysis of 3D SDF Figures (in process).


The book has been translated into American English.

---------------------------------------------------------------------------------------------------------------------------------

The package version 0.0.4, includes a new procedural shape:

' Potion SDF.
' Pentagon SDF.
' Segment SDF.

